//
//  Define.h
//  Lesson3
//
//  Created by Nguyen Nam on 4/11/18.
//  Copyright © 2018 Nguyen Nam. All rights reserved.
//

#ifndef Define_h
#define Define_h

#define ROLL_NO @"rollNo"
#define NAME  @"name"
#define EMAIL @"email"
#define GENDER @"gender"
#define RELATIONSHIP @"relationShip"
#define AGE @"age"
#define FIND_LOVER @"findLover"
#define YEAR @"year"

#endif /* Define_h */
