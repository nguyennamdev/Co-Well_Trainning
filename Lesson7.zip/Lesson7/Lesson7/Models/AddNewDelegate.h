//
//  AddNewDelegate.h
//  Lesson7
//
//  Created by Nguyen Nam on 4/23/18.
//  Copyright © 2018 Nguyen Nam. All rights reserved.
//

@protocol AddNewDelegate <NSObject>

- (void)addedNewPerson;

@end
