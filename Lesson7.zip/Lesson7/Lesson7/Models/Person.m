//
//  Person.m
//  Lesson7
//
//  Created by Nguyen Nam on 4/24/18.
//  Copyright © 2018 Nguyen Nam. All rights reserved.
//

#import "Person.h"

@implementation Person


@end
