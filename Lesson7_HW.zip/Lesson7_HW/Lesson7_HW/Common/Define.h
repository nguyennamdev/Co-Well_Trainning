//
//  Define.h
//  Lesson7_HW
//
//  Created by Nguyen Nam on 4/26/18.
//  Copyright © 2018 Nguyen Nam. All rights reserved.
//

#ifndef Define_h
#define Define_h

#define USER_ID @"uid"
#define USER_NAME @"name"
#define USER_EMAIL @"email"
#define USER_PASSWORD @"password"
#define USER_PHONE @"phoneNumber"
#define USER_IS_SHIPPER @"isShipper"

#endif /* Define_h */
