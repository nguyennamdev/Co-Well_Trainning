//
//  AddEditStudentViewController.h
//  Lesson7_HW
//
//  Created by Nguyen Nam on 4/25/18.
//  Copyright © 2018 Nguyen Nam. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddEditStudentDelegate.h"

@interface AddEditStudentViewController : UIViewController
@property (strong, nonatomic) id<AddEditStudentDelegate> delegate;
@property (nonatomic) NSInteger studentIdToEdit;
@end
