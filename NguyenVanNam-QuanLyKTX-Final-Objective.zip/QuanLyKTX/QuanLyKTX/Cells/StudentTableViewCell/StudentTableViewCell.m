//
//  StudentTableViewCell.m
//  QuanLyKTX
//
//  Created by Nguyen Nam on 5/5/18.
//  Copyright © 2018 Nguyen Nam. All rights reserved.
//

#import "StudentTableViewCell.h"

@implementation StudentTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.backgroundColor = [UIColor clearColor];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
