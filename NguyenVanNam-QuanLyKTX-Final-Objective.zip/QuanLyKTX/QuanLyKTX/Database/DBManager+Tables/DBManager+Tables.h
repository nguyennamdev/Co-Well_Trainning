//
//  DBManager+Tables.h
//  QuanLyKTX
//
//  Created by Nguyen Nam on 5/2/18.
//  Copyright © 2018 Nguyen Nam. All rights reserved.
//

#import "DBManager.h"

@interface DBManager (Tables)

- (void)showTables;

@end
