//
//  Currency.swift
//  ThirdDemo
//
//  Created by Nguyen Nam on 5/15/18.
//  Copyright © 2018 Nguyen Nam. All rights reserved.
//

import Foundation


enum Currency : Int {
    case USD = 1
    case VND = 22000
    case YEN = 109
}
