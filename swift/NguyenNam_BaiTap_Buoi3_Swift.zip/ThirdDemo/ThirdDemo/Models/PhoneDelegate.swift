//
//  PhoneDelegate.swift
//  ThirdDemo
//
//  Created by Nguyen Nam on 5/15/18.
//  Copyright © 2018 Nguyen Nam. All rights reserved.
//

import Foundation

protocol PhoneDelegate {
    
    func addNewPhone(phone:Phone)
    
}
